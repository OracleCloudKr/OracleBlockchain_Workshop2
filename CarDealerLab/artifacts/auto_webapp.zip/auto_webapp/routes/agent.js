var express = require('express');
var router = express.Router();
var path = require('path');
var scriptName = path.basename(__filename);
var log4js = require('log4js');
var logger = log4js.getLogger(scriptName);
var fs = require('fs');
var http = require('http');
var jsondata = require('./data.json');
var http = require('http');
var https = require('https');

function cloneObj(obj) {
  return JSON.parse(JSON.stringify(obj));
}

router.get('/config', function(req, res, next) {
  res.send(globalconfig);
});

router.put('/config', function(req, res, next) {
  var data = req.body;
  if (!data.gw_endpoint) {
    res.send('invalid data');
  }
  globalconfig.gw_endpoint = data.gw_endpoint;
  globalconfig.chaincode_ver = data.chaincode_ver;
  fs.writeFile('config.json', JSON.stringify(globalconfig, null, 2), 'utf8', function() {
    res.send('OK');
  });
});

function gwRESTCall(reqdata) {
  return new Promise((resolve, reject) => {
    var config = reqdata.config;
    var data = {
      "channel": config.channel,
      "chaincode": config.chaincode_name,
      "method": reqdata.method,
      "args": reqdata.args,
      "chaincodeVer": config.chaincode_ver
    };
    var dataStr = JSON.stringify(data);
    logger.debug("dataStr=======" + dataStr);
    var client = http;
    if(config.gw_endpoint.indexOf('https:') != -1)
    client = https;
    var endpoint = config.gw_endpoint.replace(/https?:\/\//, '');
    var parts = endpoint.split(':');
    var phostname = parts[0];
    var pport = 0;
    if(parts[1].indexOf("/")>0){
      var portArr = parts[1].split('/');
      pport = portArr[0];
    }else{
      pport = part[1];
    }
    
    var options = {
      hostname: phostname,
      port: pport,
      path: `/restproxy/api/v2/channels/${config.channel}/${reqdata.action}`,
      method: 'POST',
      auth: `${config.username}:${config.password}`,
      rejectUnauthorized: false,
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(dataStr)
      }
    };

    // options.agent = new http.Agent(options);

    const httpreq = client.request(options, (httpres) => {
      logger.debug('STATUS: ' + httpres.statusCode);
      logger.debug('HEADERS: ' + JSON.stringify(httpres.headers));
      logger.debug('BODY: ' + httpres.body);
      httpres.setEncoding('utf8');
      var body = '';
      httpres.on('data', function(chunk) {
        body += chunk;
      });
      httpres.on('end', function() {
        logger.debug('end res BODY: ' + body)
        if(body.indexOf('401 Authorization Required') != -1) {
          reject(`ERROR: Request rejected with: 401 Authorization Required`);
          return;
        } else if(body.indexOf('Not Found -') != -1) {
          reject('ERROR: 404 ' + body);
          return;
        }

        var obj = null;
        try {
                obj = JSON.parse(body);
        } catch (e) {
                console.error(e);
        }
        
        if (obj.returnCode == 'Success') {
          var ret;
          if(reqdata.action == 'chaincode-queries') {
            ret = obj.result;
          } else {
            ret = obj;
          }
          resolve(ret);
        } else {
logger.debug("---Fail : " + body);
          reject(obj.info);
        }
      });
    });

    httpreq.on('error', (e) => {
logger.debug("---Error : " + e);
      console.error(e);
      reject(e.toString());
    });
    httpreq.write(dataStr);
    httpreq.end();
  });
}

router.post('/query/:key', function(req, res, next) {
  var key = req.params.key;
  var config = req.body.config;

  var channelMapping;
  if(globalconfig.channel_mapping) {
    var mappingKey = Object.keys(globalconfig.channel_mapping)[0];
    var mappings = globalconfig.channel_mapping[mappingKey];
    if(config.channel == mappingKey) {
      channelMapping = mappings;
    }
  }

  if(channelMapping) {
    var promises = [];
    channelMapping.forEach(val => {
      var newConfig = cloneObj(config);
      newConfig.channel = val;
      promises.push(gwRESTCall({
        action: 'chaincode-queries',
        method: 'getHistoryForRecord',
        args: ['getHistoryForRecord', key],
        config: newConfig
      }));
    });

    Promise.all(promises).then(results => {
      var ret = [];
      results.forEach(val => {
        ret = ret.concat(JSON.parse(val.payload));
      });
      res.send(JSON.stringify(ret));
    }).catch(err => {
      res.status(500).send(err.toString());
    });
  } else {
logger.debug("---- channelMapping is null");
logger.debug("---- key="+key);
    gwRESTCall({
      action: 'chaincode-queries',
      method: 'getHistoryForRecord',
      args: ['getHistoryForRecord', key],
      config: config
    }).then(result => {
      logger.debug("send======" + JSON.stringify(result.payload));
      res.send(result.payload);
    }).catch(err => {
      logger.debug("---- error : " + err);
      res.status(500).send(err);
    });
  }
});

router.post('/asset/:owner', function(req, res, next) {
  var owner = req.params.owner;
  var config = req.body.config;
  gwRESTCall({
    action: 'chaincode-queries',
    method: 'queryVehiclePartByOwner',
    args: ['queryVehiclePartByOwner', owner],
    config: config
  }).then(result => {
    res.send(result);
  }).catch(err => {
    res.status(500).send(err);
  });
});

router.post('/assetVehicle/:owner', function(req, res, next) {
    var owner = req.params.owner;
    var config = req.body.config;
    gwRESTCall({
      action: 'chaincode-queries',
      method: 'queryVehicleByOwner',
      args: ['queryVehicleByOwner', owner],
      config: config
    }).then(result => {
      res.send(result);
    }).catch(err => {
      res.status(500).send(err);
    });
  });

router.post('/invoke', function(req, res, next) {
  var data = req.body.data;
  var config = req.body.config;
  gwRESTCall({
    action: 'transactions',
    method: data.method,
    args: data.args,
    config: config
  }).then(result => {
    res.send(result);
  }).catch(err => {
    res.status(500).send(err);
  });
});

module.exports = router;
