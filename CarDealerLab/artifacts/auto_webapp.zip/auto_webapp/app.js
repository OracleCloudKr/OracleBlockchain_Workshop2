var express = require('express');
var morgan = require('morgan');
var bodyParser = require('body-parser');
var path = require('path');
var scriptName = path.basename(__filename);
var log4js = require('log4js');
var logger = log4js.getLogger(scriptName);
var util = require('./utils');
var os = require("os");


var app = express();
//app.set('view engine', 'html');

global.globalconfig = require('./config.json');
var gwend = "https://" + os.hostname() + ":10001/restproxy";
global.globalconfig.gw_endpoint = gwend;
console.log(global.globalconfig.gw_endpoint);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname, 'public')));

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", req.headers.origin || "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  res.header("Access-Control-Allow-Credentials", true);
  next();
});

if(process.env.MOCK_ENABLE == 'yes')
  app.use(`/bcsgw/rest/v1/transaction`, require('./routes/demo'));
  
app.use(`/agent`, require('./routes/agent'));

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  if (req.originalUrl.indexOf('es6-promise/es6-promise.map') != -1) {
    return;
  }
  var err = new Error('Not Found - ' + req.originalUrl);
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development'
    ? err
    : {};

  logger.error(err);
  // render the error page
  res.status(err.status || 500);
  res.send(err instanceof Error
    ? err.message
    : err);
});

module.exports = app;
