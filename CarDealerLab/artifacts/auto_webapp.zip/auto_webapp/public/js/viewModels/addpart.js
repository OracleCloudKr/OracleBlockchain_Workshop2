/**
* Copyright (c) 2014, 2017, Oracle and/or its affiliates.
* The Universal Permissive License (UPL), Version 1.0
*/

define(['ojs/ojcore', 'knockout', 'jquery', 'ojs/ojknockout', 'ojs/ojselectcombobox', 'ojs/ojchart', 'ojs/ojcheckboxset', 'ojs/ojdialog', 'ojs/ojradioset',
'ojs/ojlistview', 'ojs/ojinputtext', 'ojs/ojmenu', 'ojs/ojlistview', 'ojs/ojdatetimepicker', 'ojs/ojtimezonedata',
'ojs/ojarraytabledatasource', 'ojs/ojcollapsible', 'ojs/ojinputnumber', 'ojs/ojtabs', 'ojs/ojtable', 'ojs/ojknockout-validation', 'ojs/ojbutton'],
function (oj, ko, $) {
  function MainViewModel() {
    var self = this;
    self.serialNumber = ko.observable();
    self.assembler = ko.observable();
    self.partname = ko.observable();
    self.assemblyDate = ko.observable();

    self.addCarAction = function() {
        var config = cloneObj(globalconf);
        var aDate = Date.parse(self.assemblyDate() + " 09:00:00 GMT+0900") / 1000;
        var reqdata = {"method":"initVehiclePart", "args":
            ["initVehiclePart", self.serialNumber(), self.assembler(), String(aDate), self.partname(), globalconf.org, "false", String(aDate)]};

      $.ajax({
        url: '/agent/invoke',
        contentType: 'application/json',
        method: 'POST',
        data:  JSON.stringify({config: config, data: reqdata})
      }).done(function(resp){
        var text = JSON.stringify(resp, null, 2);
        alert("Success");
      }).fail(function(jqXHR){
        console.log(jqXHR);
        alert(`Error: ${jqXHR.responseText}`);
      }).always(function() {
        hideQueryLoading(rmspaces('Add'));
      });
    }

    function rmspaces(str) {
      return str.replaceAll(' ', '_');
    }


  } // MainViewModel end

  return new MainViewModel();
});
