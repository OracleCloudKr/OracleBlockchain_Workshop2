/**
 * Copyright 2016 IBM All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an 'AS IS' BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

var path = require('path');
var fs = require('fs');
var os = require('os');
var util = require('util');
var exec = require('child_process').exec;
var log4js = require('log4js');
var logger = log4js.getLogger('utils.js');

function readFile(path) {
    return new Promise((resolve, reject) => {
        fs.readFile(path, (err, data) => {
            if (!!err)
                reject(new Error('Failed to read file ' + path + ' due to error: ' + err));
            else
                resolve(data);
        });
    });
}

function readAllFiles(dir) {
    var files = fs.readdirSync(dir);
    var certs = [];
    files.forEach((file_name) => {
        let file_path = path.join(dir,file_name);
        console.log(' looking at file ::'+file_path);
        let data = fs.readFileSync(file_path);
        certs.push(data);
    });
    return certs;
}

module.exports.setLogger = function(logger) {
  var development = process.env.NODE_ENV === 'development';
  if (development) {
    logger.setLevel('DEBUG');
    logger.debug("Set logger in DEBUG mode.");
  }
}

function rmObjProperty(obj, key) {
  for(let prop in obj) {
    if (prop === key)
      delete obj[prop];
    else if (typeof obj[prop] === 'object')
      rmObjProperty(obj[prop], key);
  }
};

module.exports.rmObjProperty = rmObjProperty;


module.exports.getConfigSetting = function(name, default_value) {
    return sdkutils.getConfigSetting(name, default_value);
}

module.exports.setConfigSetting = function(name, value) {
    return sdkutils.setConfigSetting(name, value);
}

module.exports.setLog4jsConfig = function(config) {
    log4js.configure(config);
}

module.exports.setLogConfig = function(config) {
    log4js.configure(config);
}

module.exports.getEnvValue = function(env) {
    if (env == undefined || env == '') {
		return 'unset';
	} else {
		return env;
	}
}

/* node management related function
 */
function fileInit(filename) {
	if (fs.existsSync(filename)) {
		return;
	} else {
		var empty = {}
		fs.writeFileSync(filename, JSON.stringify(empty));
		return;
	}
}

var mkdirs = module.exports.mkdirs = function(dirpath, callback) {
    fs.stat(dirpath, function(err, stats){
        if(err && err.code != 'ENOENT'){
            callback(err);
        }else if(stats && stats.isDirectory()) {
            callback();
        }else {
            mkdirs(path.dirname(dirpath), function(){
                fs.mkdir(dirpath, callback);
            });
        }
    });
};
