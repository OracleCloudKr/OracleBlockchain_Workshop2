/**
* Copyright (c) 2014, 2017, Oracle and/or its affiliates.
* The Universal Permissive License (UPL), Version 1.0
*/
define(['ojs/ojcore', 'knockout', 'jquery', 'ojs/ojknockout', 'ojs/ojselectcombobox', 'ojs/ojchart', 'ojs/ojcheckboxset', 'ojs/ojdialog', 'ojs/ojradioset',
'ojs/ojlistview', 'ojs/ojinputtext', 'ojs/ojmenu', 'ojs/ojlistview', 'ojs/ojdatetimepicker', 'ojs/ojtimezonedata',
'ojs/ojarraytabledatasource', 'ojs/ojcollapsible', 'ojs/ojinputnumber', 'ojs/ojtabs', 'ojs/ojtable', 'ojs/ojknockout-validation', 'ojs/ojbutton'],
function (oj, ko, $) {
  function MainViewModel() {
    var self = this;
    // self.companyCookie = getCookie('company');
    // self.loginName = ko.observable(self.companyCookie);

    self.companyName = ko.observable();
    self.companyPass = ko.observable();

    self.tabs = ko.observableArray([]);

    // self.handleActivated = function (info) {
    // };

    self.loginAction = function() {
      var compName = self.companyName();
      // console.log(compName);
      if(!compName) {
        return;
      }
      self.companyName('');
      self.companyPass('');

      var griddata = ko.observableArray();
      var datasource = new oj.ArrayTableDataSource(griddata, {idAttribute: "serialNumber"});
      var gridcolumns = ko.observableArray([]);

      // $.ajax({
      //   url: `/agent/asset/${compName}`,
      //   contentType: 'application/json',
      //   method: 'POST',
      //   data: JSON.stringify({config: globalconf})
      // }).done(function(resp){
      //   var obj = JSON.parse(resp);
      //   obj = obj.map(val => {
      //     return val.Value;
      //   });
      //   griddata(obj.map(translateDates));
      //   var columns = Object.keys(obj[0]).map(val => {
      //     return {headerText: val, field: val, sortProperty: val};
      //   });
      //   removeDocTypeField(columns);
      //   gridcolumns(columns);
      // }).fail(function(xhr) {
      //   console.log(xhr.responseText);
      // }).always(function() {
        self.tabs.push({
          label: compName,
          datasource: datasource,
          gridcolumns: gridcolumns,
          serialNum: ko.observable(),
          carPartOwner: ko.observable(),
          chassisNum: ko.observable(),
          carOwner: ko.observable(),
          apiDetailInfo: ko.observable(),
          logoutAction: self.logoutAction,
          transferVehiclePart: self.transferVehiclePart,
          transferVehicle: self.transferVehicle,
        });
        $("#tabs").ojTabs("refresh");
      // });
    }

    self.logoutAction = function() {
      self.tabs.remove(this);
      $("#tabs").ojTabs("refresh");
    }

    function getReqdata(method, tab) {
      var reqdata, key, newOwner;
      if(method == 'transferVehiclePart') {
        var key = tab.serialNum();
        var newOwner = tab.carPartOwner();
      } else if(method == 'transferVehicle') {
        var key = tab.chassisNum();
        var newOwner = tab.carOwner();
      }

      if(!key || !newOwner) {
        return null;
      }
      return {"method":method,"args":[key, tab.label, newOwner]};
    }

    function hideLoadingIcon(label) {
      hideQueryLoading(label+'tran1');
      hideQueryLoading(label+'tran2');
    }

    function transfer(method, tab) {
      var reqdata = getReqdata(method, tab);
      if(!reqdata) {
        console.log('skip');
        hideLoadingIcon(tab.label);
        return;
      }

      var config = cloneObj(globalconf);
      if(self.channelVal().length > 0)
        config.channel = self.channelVal()[0];

      $.ajax({
        url: '/agent/invoke',
        contentType: 'application/json',
        method: 'POST',
        data:  JSON.stringify({config: config, data: reqdata})
      }).done(function(resp){
        var text = JSON.stringify(resp, null, 2);
        tab.apiDetailInfo(text.replaceAll('\n','<br>').replaceAll(' ','&nbsp;'));
      }).fail(function(jqXHR){
        console.log(jqXHR);
        alert(`Error: ${jqXHR.responseText}`);
      }).always(function() {
        hideLoadingIcon(rmspaces(tab.label));
      });
    }

    self.transferVehiclePart = function() {
      showQueryLoading(rmspaces(this.label)+'tran1');
      transfer('transferVehiclePart', this);
    }

    self.transferVehicle = function() {
      showQueryLoading(rmspaces(this.label)+'tran2');
      transfer('transferVehicle', this);
    }

    self.enterPressed = function(event, data) {
      if(event.which != 13) return;
      self.loginAction();
    }

    function rmspaces(str) {
      return str.replaceAll(' ', '_');
    }

    self.channelOptions = ko.observableArray([]);
    self.channelVal = ko.observableArray([]);
    if(globalconf.channel_mapping) {
      var mappingKey = Object.keys(globalconf.channel_mapping)[0];
      var mappings = globalconf.channel_mapping[mappingKey];
      if(globalconf.channel == `channel${mappingKey}`) {
        self.channelOptions(mappings.map(val => {
          return {value: `channel${val}`, label: `channel${val}`};
        }));
      }
    }
  } // MainViewModel end

  return new MainViewModel();
});
