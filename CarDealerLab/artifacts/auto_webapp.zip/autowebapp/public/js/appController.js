/**
 * Copyright (c) 2014, 2017, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your application specific code will go here
 */
define([
  'ojs/ojcore',
  'knockout',
  'jquery',
  'obcsapi',
  'ojs/ojrouter',
  'ojs/ojknockout',
  'ojs/ojarraytabledatasource',
  'ojs/ojoffcanvas',
  'ojs/ojdialog',
  'ojs/ojinputtext',
  'ojs/ojselectcombobox',
  'ojs/ojinputnumber'
], function(oj, ko, $, obcsapi) {
  function ControllerViewModel() {
    var self = this;

    $.ajaxSetup({
      xhrFields: {
        withCredentials: true
      }
    });

    $(document).ajaxError(function(event, jqxhr, settings, thrownError) {
      if (settings.url == "ajax/missing.html") {
        $("div.log").text("Triggered ajaxError handler.");
      }
    });

    function getParam(name, url) {
      if (!url)
        url = window.location.href;
      name = name.replace(/[\[\]]/g, "\\$&");
      var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
      if (!results)
        return null;
      if (!results[2])
        return '';
      return decodeURIComponent(results[2].replace(/\+/g, " "));
    }

    // User Info used in Global Navigation area
    self.user = {};
    self.isAmin = function() {
      return true;
    }

    // Media queries for repsonsive layouts
    var smQuery = oj.ResponsiveUtils.getFrameworkQuery(oj.ResponsiveUtils.FRAMEWORK_QUERY_KEY.SM_ONLY);
    self.smScreen = oj.ResponsiveKnockoutUtils.createMediaQueryObservable(smQuery);
    var mdQuery = oj.ResponsiveUtils.getFrameworkQuery(oj.ResponsiveUtils.FRAMEWORK_QUERY_KEY.MD_UP);
    self.mdScreen = oj.ResponsiveKnockoutUtils.createMediaQueryObservable(mdQuery);

    // Router setup
    self.router = oj.Router.rootInstance;
    let option = {
    'addpart': {
            label: 'Add Part',
            isDefault: true
      },
     'addcar': {
            label: 'Add Car',
            isDefault: true
      },
      'trace': {
        label: 'Trace',
        isDefault: true
      },
      'search': {
        label: 'Search',
        isDefault: true
      },
      'transfer': {
        label: 'Transfer'
      }
    };
    self.router.configure(option);
    oj.Router.defaults['urlAdapter'] = new oj.Router.urlParamAdapter();

    // Navigation setup
    var navData = [
    {
            name: 'Add Part',
            id: 'addpart'
    },
      {
        name: 'Add Car',
        id: 'addcar'
      },
      {
        name: 'Trace',
        id: 'trace'
      }, {
        name: 'Search',
        id: 'search'
      }, {
        name: 'Transfer',
        id: 'transfer'
      }
    ];
    self.navDataSource = new oj.ArrayTableDataSource(navData, {idAttribute: 'id'});

    // Drawer
    // Close offcanvas on medium and larger screens
    self.mdScreen.subscribe(function() {
      oj.OffcanvasUtils.close(self.drawerParams);
    });
    self.drawerParams = {
      displayMode: 'push',
      selector: '#navDrawer',
      content: '#pageContent'
    };
    // Called by navigation drawer toggle button and after selection of nav drawer item
    self.toggleDrawer = function() {
      return oj.OffcanvasUtils.toggle(self.drawerParams);
    };

    // Add a close listener so we can move focus back to the toggle button when the drawer closes
    $("#navDrawer").on("ojclose", function() {
      $('#drawerToggleButton').focus();
    });

    self.requesttimeout = ko.observable('');
    self.loglevel = ko.observable('info');

    // Footer
    function footerLink(name, id, linkTarget) {
      this.name = name;
      this.linkId = id;
      this.linkTarget = linkTarget;
    }

    self.footerLinks = ko.observableArray([
      new footerLink('About Oracle', 'aboutOracle', 'http://www.oracle.com/us/corporate/index.html#menu-about'),
      new footerLink('Contact Us', 'contactUs', 'http://www.oracle.com/us/corporate/contact/index.html'),
      new footerLink('Legal Notices', 'legalNotices', 'http://www.oracle.com/us/legal/index.html'),
      new footerLink('Terms Of Use', 'termsOfUse', 'http://www.oracle.com/us/legal/terms/index.html'),
      new footerLink('Your Privacy Rights', 'yourPrivacyRights', 'http://www.oracle.com/us/legal/privacy/index.html')
    ]);

    Date.prototype.format = function(fmt) {
      var o = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours() % 12 == 0
          ? 12
          : this.getHours() % 12,
        "H+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S": this.getMilliseconds()
      };
      var week = {
        "0": "/u65e5",
        "1": "/u4e00",
        "2": "/u4e8c",
        "3": "/u4e09",
        "4": "/u56db",
        "5": "/u4e94",
        "6": "/u516d"
      };
      if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
      }
      if (/(E+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1)
          ? (RegExp.$1.length > 2
            ? "/u661f/u671f"
            : "/u5468")
          : "") + week[this.getDay() + ""]);
      }
      for (var k in o) {
        if (new RegExp("(" + k + ")").test(fmt)) {
          fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1)
            ? (o[k])
            : (("00" + o[k]).substr(("" + o[k]).length)));
        }
      }
      return fmt;
    };
    Date.prototype.addHour = function(hour) {
      this.setTime(this.getTime() + (hour * 3600 * 1000));
      return this;
    };
    String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
    };

    cloneObj = function(obj) {
      return JSON.parse(JSON.stringify(obj));
    }

    setCookie = function(cname, cvalue) {
        var d = new Date();
        d.setTime(d.getTime() + (365 * 24 * 60 * 60 * 1000));
        var expires = "expires="+d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

    getCookie = function(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for(var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }

    globalconf = {};
    self.settings = {
      config: {
        org : ko.observable(),
        gw_endpoint: ko.observable(),
        channel: ko.observable(),
        chaincode_name: ko.observable(),
        chaincode_ver: ko.observable(),
        username: ko.observable(),
        password: ko.observable(),
        title: ko.observable(),
        configurable: ko.observable()
      },
      configCust: {
        org : ko.observable(),
        gw_endpoint: ko.observable(),
        channel: ko.observable(),
        chaincode_name: ko.observable(),
        chaincode_ver: ko.observable(),
        username: ko.observable(),
        password: ko.observable(),
        title: ko.observable(),
        configurable: ko.observable()
      },
      init: function() {
        $.get('/agent/config').done(function(resp) {
          for(var i in self.settings.config) {
            var val = getCookie(i);
            // console.log(`val: ${val}`);
            if(val) { // in cookie, use cookie value
              self.settings.config[i](val);
              self.settings.configCust[i](true);
            } else { // use server config value
              self.settings.config[i](resp[i]);
              self.settings.configCust[i](false);
            }
            // console.log(self.settings.config[i]());
            globalconf[i] = self.settings.config[i]();
          }
          globalconf.channel_mapping = resp.channel_mapping;
        });
      }
    }
    self.settings.init();

    // Header
    // Application Name used in Branding Area
    self.appTitle = ko.observable("Car Blockchain Network");

    self.handleConfig = function() {
      self.settings.init();
      $('#dialog-config').ojDialog('open');
    }
    self.enterPressed = function(event, data) {
      if(event.which != 13) return;
      self.configSubmit();
    }
    self.configSubmit = function() {
      for(var i in self.settings.config) {
        var val = self.settings.config[i]();
        if(val instanceof String)
          val = val.trim();
        if(val && val != globalconf[i]) {
          setCookie(i, val);
        }
      }
      self.settings.init();
      $('#dialog-config').ojDialog('close');
    }
  }

  dateSecToISO = function(str) {
    // return oj.IntlConverterUtils.dateToLocalIso(new Date(Number(''+str+'000')));
    return new Date(Number(''+str+'000')).toISOString();
  }

  translateDates = function(val) {
    if(val.assemblyDate) {
      val.assemblyDate = dateSecToISO(val.assemblyDate);
    }
    if(val.recallDate) {
      val.recallDate = dateSecToISO(val.recallDate);
    }
    return val;
  }

  removeDocTypeField = function(columns) {
    var docTypeEntry;
    columns.forEach(col => {
      if(col.headerText == 'docType') {
        docTypeEntry = col;
      }
    });
    if(docTypeEntry) {
      var index = columns.indexOf(docTypeEntry);
      columns.splice(index, 1);
    }
  }

  hideQueryLoading = function(key) {
      $(`#${key}-loading`).hide();
  }

  showQueryLoading = function(key) {
      $(`#${key}-loading`).show();
  }

  return new ControllerViewModel();
});
